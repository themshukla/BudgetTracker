import React from "react";
import {
  View,
  TextInput,
  Pressable,
  KeyboardAvoidingView,
  Platform,
  StyleSheet,
  Modal as RNModal,
} from "react-native";
import FontAwesome5 from "@expo/vector-icons/FontAwesome5";
import Text from "./Text";

const ItemsInputModal = ({
  modalVisible,
  setModalVisible,
  name,
  setName,
  setnetworth,
  networth,
  planned,
  setPlanned,
  spent,
  setSpent,
  setRemaining,
  handleSave,
  errors,
  setErrors,
  modalType,
  setModalEditMode,
}) => {
  return (
    <RNModal
      animationType="slide"
      transparent={true}
      visible={modalVisible}
      onRequestClose={() => {
        setModalVisible(!modalVisible);
      }}
    >
      <View style={styles.centeredView}>
        <KeyboardAvoidingView
          behavior={Platform.OS === "ios" ? "padding" : "height"}
          style={{ width: "100%" }}
        >
          <View style={styles.modalView}>
            <Pressable
              style={{ left: 0 }}
              onPress={() => {
                if (modalType === "asset" || modalType === "liability") {
                  setName("");
                  setnetworth("");
                  setErrors({
                    ...errors,
                    name: "",
                    networth: "",
                  });
                } else {
                  setName("");
                  setPlanned("");
                  setSpent("");
                  setRemaining("");
                  setErrors({
                    ...errors,
                    name: "",
                    planned: "",
                    spent: "",
                    // remaining: "",
                  });
                }
                setModalEditMode(null);
                setModalVisible(!modalVisible);
              }}
            >
              <FontAwesome5 name="times-circle" size={24} color="#800000" />
            </Pressable>
            <Text style={styles.modalText}>Enter Details</Text>

            <View style={styles.inputContainer}>
              <Text style={styles.label}>Name:</Text>
              <View style={{ width: "100%" }}>
                <TextInput
                  style={styles.modalInput}
                  placeholder="Enter your category name"
                  value={name}
                  onChangeText={(value) => {
                    setName(value);
                    setErrors({
                      ...errors,
                      name: "",
                    });
                  }}
                />
                {errors.name ? (
                  <Text style={styles.errorText}>{errors.name}</Text>
                ) : null}
              </View>
            </View>

            {(modalType === "asset" || modalType === "liability") && (
              <>
                <View style={styles.inputContainer}>
                  <Text style={styles.label}>Networth:</Text>
                  <View style={{ width: "100%" }}>
                    <TextInput
                      style={styles.modalInput}
                      placeholder="Enter amount"
                      value={networth}
                      onChangeText={(value) => {
                        setnetworth(value);
                        setErrors({
                          ...errors,
                          networth: "",
                        });
                      }}
                      keyboardType="numeric"
                    />
                    {errors.networth ? (
                      <Text style={styles.errorText}>{errors.networth}</Text>
                    ) : null}
                  </View>
                </View>
              </>
            )}

            {modalType !== "asset" && modalType !== "liability" && (
              <>
                <View style={styles.inputContainer}>
                  <Text style={styles.label}>Planned:</Text>
                  <View style={{ width: "100%" }}>
                    <TextInput
                      style={styles.modalInput}
                      placeholder="Enter planned amount"
                      value={planned}
                      onChangeText={(value) => {
                        setPlanned(value);
                        setErrors({
                          ...errors,
                          planned: "",
                        });
                      }}
                      keyboardType="numeric"
                    />
                    {errors.planned ? (
                      <Text style={styles.errorText}>{errors.planned}</Text>
                    ) : null}
                  </View>
                </View>

                <View style={styles.inputContainer}>
                  <Text style={styles.label}>Spent:</Text>
                  <View style={{ width: "100%" }}>
                    <TextInput
                      style={styles.modalInput}
                      placeholder="Enter spent amount"
                      value={spent}
                      onChangeText={(value) => {
                        setSpent(value);
                        setErrors({ ...errors, spent: "" });
                      }}
                      keyboardType="numeric"
                    />
                    {errors.spent ? (
                      <Text style={styles.errorText}>{errors.spent}</Text>
                    ) : null}
                  </View>
                </View>

                {/* <View style={styles.inputContainer}>
                  <Text style={styles.label}>Remaining:</Text>
                  <View style={{ width: "100%" }}>
                    <TextInput
                      style={styles.modalInput}
                      placeholder="Enter remaining amount"
                      value={remaining}
                      onChangeText={(value) => {
                        setRemaining(value);
                        setErrors({
                          ...errors,
                          remaining: "",
                        });
                      }}
                      keyboardType="numeric"
                    />
                    {errors.remaining ? (
                      <Text style={styles.errorText}>{errors.remaining}</Text>
                    ) : null}
                  </View>
                </View> */}
              </>
            )}

            <View style={styles.buttonContainer}>
              <Pressable style={styles.button} onPress={handleSave}>
                <FontAwesome5 name="save" size={20} color="#6b8e23" />
                <Text style={{ color: "#6b8e23", marginLeft: 5 }}>Save</Text>
              </Pressable>
            </View>
          </View>
        </KeyboardAvoidingView>
      </View>
    </RNModal>
  );
};

const styles = StyleSheet.create({
  centeredView: {
    flex: 1,
    justifyContent: "flex-end",
    alignItems: "center",
  },
  modalText: {
    marginBottom: 15,
    textAlign: "center",
    fontSize: 22,
    fontWeight: "bold",
  },
  modalView: {
    width: "100%",
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    paddingHorizontal: 35,
    paddingVertical: 20,
    backgroundColor: "#322A28",
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: -2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 5,
  },
  label: {
    width: "30%",
    fontSize: 20,
    fontWeight: "600",
    textAlign: "right",
    marginRight: 10,
  },
  buttonContainer: {
    marginTop: 10,
    flexDirection: "row",
    justifyContent: "flex-end",
    width: "100%",
  },
  button: {
    flexDirection: "row",
    justifyContent: "flex-end",
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#6b8e23",
    borderRadius: 10,
    padding: 4,
    width: "auto",
    marginRight: 15,
  },
  errorText: {
    color: "#800000",
    fontSize: 14,
    marginTop: 5,
  },
  modalInput: {
    width: "60%",
    height: 40,
    textAlign: "left",
    color: "#BA9731",
    fontSize: 16,
    fontWeight: "bold",
    backgroundColor: "transparent",
    padding: 5,
    borderBottomWidth: 1,
    borderColor: "#fefefe",
  },
});

export default ItemsInputModal;
