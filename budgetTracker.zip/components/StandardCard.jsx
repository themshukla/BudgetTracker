// StandardCard.jsx
import React, { useState, useRef } from "react";
import { View, TextInput, Pressable, useWindowDimensions } from "react-native";
import { AntDesign, Ionicons, EvilIcons } from "@expo/vector-icons";
import Text from "./Text";
import styles from "../utilities/styles";
import {
  Menu,
  MenuOptions,
  MenuOption,
  MenuTrigger,
} from "react-native-popup-menu";
import Swipeable from "react-native-gesture-handler/ReanimatedSwipeable";
import Reanimated, {
  useAnimatedStyle,
  interpolate,
} from "react-native-reanimated";
import { formatCurrency } from "../utilities/formartCurrency";
import { TabView, TabBar } from "react-native-tab-view";

const StandardCard = ({
  card,
  handleEdit,
  removeItem,
  setModalVisible,
  setCurrentCardId,
  addCard,
  removeCard,
  itemType,
  setItemType,
}) => {
  const discretionarySwipeableRefs = useRef([]);
  const nonDiscretionarySwipeableRefs = useRef([]);
  const [index, setIndex] = useState(0);
  const layout = useWindowDimensions();

  const tabRoutes = [
    { key: "planned", title: "Planned" },
    { key: "spent", title: "Spent" },
    { key: "remaining", title: "Remaining" },
  ];

  const RightAction = (progress, dragX, item, i, type) => {
    const styleAnimation = useAnimatedStyle(() => {
      return {
        opacity: interpolate(dragX.value, [-100, 0], [1, 0], {
          extrapolateLeft: "clamp",
          extrapolateRight: "clamp",
        }),
        transform: [
          {
            scale: interpolate(dragX.value, [-100, 0], [1, 0.7], {
              extrapolateLeft: "clamp",
              extrapolateRight: "clamp",
            }),
          },
        ],
      };
    });

    const refArray =
      type === "nonDiscretionary"
        ? nonDiscretionarySwipeableRefs.current
        : discretionarySwipeableRefs.current;

    return (
      <Reanimated.View
        style={[
          styleAnimation,
          {
            flexDirection: "row",
            alignItems: "center",
            backgroundColor: "#333",
            borderRadius: 8,
            paddingHorizontal: 10,
            height: "95%",
            marginVertical: 4,
            marginRight: 5,
          },
        ]}
      >
        <Pressable
          onPress={() => {
            setCurrentCardId(card.id);
            handleEdit(item);
            if (refArray[i]) refArray[i].close();
          }}
          style={{ marginRight: 10 }}
        >
          <AntDesign name="edit" size={20} color="#fefefe" />
        </Pressable>
        <Pressable
          onPress={() => {
            removeItem(card.id, item.id);
            if (refArray[i]) refArray[i].close();
          }}
        >
          <EvilIcons name="trash" size={28} color="#FF5A5F" />
        </Pressable>
      </Reanimated.View>
    );
  };

  const getValueByTab = (item) => {
    if (index === 0) return item?.planned;
    if (index === 1) return item?.spent;
    return item?.planned - item?.spent;
  };

  const getTotalByTab = (type) => {
    if (index === 0)
      return type === "discretionary"
        ? card.totalDiscretionaryPlanned
        : card.totalNonDiscretionaryPlanned;
    if (index === 1)
      return type === "discretionary"
        ? card.totalDiscretionarySpent
        : card.totalNonDiscretionarySpent;
    return type === "discretionary"
      ? card.totalDiscretionaryPlanned - card.totalDiscretionarySpent
      : card.totalNonDiscretionaryPlanned - card.totalNonDiscretionarySpent;
  };

  return (
    <View key={card.id} style={[styles.card]}>
      <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
        <View id="head" style={styles.cardHead}>
          <View style={{ width: "100%" }}>
            <View style={styles.iconContainer}>
              <Menu>
                <MenuTrigger>
                  <AntDesign name="pluscircleo" size={30} color="#BA9731" />
                </MenuTrigger>
                <MenuOptions>
                  <MenuOption onSelect={() => addCard("custom")}>
                    <Text style={styles.option}>Custom</Text>
                  </MenuOption>
                  <MenuOption onSelect={() => addCard("standard")}>
                    <Text style={styles.option}>Standard</Text>
                  </MenuOption>
                </MenuOptions>
              </Menu>
              <View style={styles.badge}>
                <Text
                  style={{
                    color: "#BA9731",
                    fontSize: 12,
                    textAlign: "center",
                  }}
                >
                  {card.type.toUpperCase()}
                </Text>
              </View>
              <Pressable onPress={() => removeCard(card.id, card.type)}>
                <Ionicons
                  name="remove-circle-outline"
                  size={30}
                  color="#FF5A5F"
                />
              </Pressable>
            </View>
          </View>
        </View>
      </View>

      {/* <View style={styles.cardBodyHeader}>
        <Text style={styles.income}>Income</Text>
        <CurrencyInput
          style={[styles.input, { width: "auto" }]}
          placeholder="$$$$"
          placeholderTextColor="#BA9731"
          value={card.income}
          onChangeValue={(value) => updateIncome(card.id, value)}
          prefix="$"
          delimiter=","
          separator="."
          precision={0}
          returnKeyType="done"
        />
      </View> */}

      <TabView
        navigationState={{ index, routes: tabRoutes }}
        onIndexChange={setIndex}
        initialLayout={{ width: layout.width }}
        swipeEnabled={false}
        renderScene={() => null}
        renderTabBar={(props) => (
          <TabBar
            {...props}
            labelStyle={{ color: "#1D160E", fontWeight: "600" }}
            indicatorStyle={{
              backgroundColor: "#fff",
              height: 2,
              width: "20%",
              marginLeft: "7%",
            }}
            style={{ backgroundColor: "#BA9731", borderRadius: 10 }}
          />
        )}
      />

      {["nonDiscretionary", "discretionary"].map((type) => {
        const items = card?.items?.[type] || [];
        const isTypeEmpty = !Array.isArray(items) || items.length === 0;

        return (
          <View key={type}>
            <View style={styles.cardBodyContent}>
              <Text style={[styles.cardItemHeader, { width: "auto" }]}>
                {type === "discretionary"
                  ? "Discretionary"
                  : "Non Discretionary"}
              </Text>
              {!isTypeEmpty && (
                <Text style={styles.cardItemHeader}>
                  {tabRoutes[index].title}
                </Text>
              )}
            </View>

            {!isTypeEmpty && <View style={styles.dividerHeader}></View>}

            {isTypeEmpty ? null : (
              <View style={{ width: "100%" }}>
                {items.map((item, i) => (
                  <Swipeable
                    key={i}
                    renderRightActions={(progress, dragX) =>
                      RightAction(progress, dragX, item, i, type)
                    }
                    dragOffsetFromLeftEdge={20}
                    onSwipeableWillOpen={() => {
                      setItemType(type);
                    }}
                    ref={(ref) => {
                      if (type === "discretionary")
                        discretionarySwipeableRefs.current[i] = ref;
                      else nonDiscretionarySwipeableRefs.current[i] = ref;
                    }}
                  >
                    <View style={styles.cardBodyContent}>
                      <Text style={styles.cardItem}>{item?.name}</Text>
                      <Text style={styles.cardItem}>
                        {formatCurrency(getValueByTab(item))}
                      </Text>
                    </View>
                  </Swipeable>
                ))}
              </View>
            )}

            {!isTypeEmpty && <View style={styles.dividerItem}></View>}

            <View style={styles.cardBodyAction}>
              <Pressable
                style={styles.button}
                onPress={() => {
                  setModalVisible(true);
                  setCurrentCardId(card.id);
                  setItemType(type);
                }}
              >
                <AntDesign name="plus" size={18} color="#BA9731" />
                <Text style={styles.buttonText}>Add</Text>
              </Pressable>
            </View>

            {!isTypeEmpty && (
              <View style={styles.foot}>
                <View style={styles.dividerItem}></View>
                <View style={styles.cardFooterContent}>
                  <Text style={styles.footerCardItem}>Total</Text>
                  <Text style={styles.footerCardItem}>
                    {formatCurrency(getTotalByTab(type))}
                  </Text>
                </View>
              </View>
            )}
          </View>
        );
      })}
    </View>
  );
};

export default StandardCard;
